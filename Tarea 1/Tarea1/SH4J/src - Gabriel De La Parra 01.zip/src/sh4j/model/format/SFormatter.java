package sh4j.model.format;

import sh4j.parser.model.SBlock;

/**
 Formatter Interface.
 First sentence should be present.
 Meaning that there should be more than one line.

 @author Gabriel De La Parra
 @version 1.0 */
public interface SFormatter {
  /**
   Appends a word to the buffer.
   First sentence should be present.
   Meaning that there should be more than one line.

   @param word string to append.
   */
  void styledWord(String word);

  /**
   Appends a character to the buffer.
   First sentence should be present.
   Meaning that there should be more than one line.

   @param character char to append.
   */
  void styledChar(char character);

  /**
   Appends a empty string to the buffer.
   First sentence should be present.
   Meaning that there should be more than one line.
   */
  void styledSpace();

  /**
   Appends a Carrier Return to the buffer.
   First sentence should be present.
   Meaning that there should be more than one line.
   */
  void styledCarrierReturn();

  /**
   Reads a block.
   First sentence should be present.
   Meaning that there should be more than one line.

   @param sblock stringBlock to read.
   */
  void styledBlock(SBlock sblock);

  /**
   Applies an HTML header to the buffer.
   First sentence should be present.
   Meaning that there should be more than one line.

   @return bufferString with style-based header;
   */
  String formattedText();
}
