package sh4j.model.highlight;

import sh4j.model.style.SStyle;

/**
 SHighlighter Interface.
 First sentence should be present.
 Meaning that there should be more than one line.

 @author Gabriel De La Parra
 @version 1.0 */
public interface SHighlighter {

  /**
   First sentence should be present.
   Meaning that there should be more than one line.

   @param text Input text that might be highlighted.
   @return Returns true if the text needs to be highlighted.
   */
  boolean needsHighLight(String text);

  /**
   First sentence should be present.
   Meaning that there should be more than one line.

   @param text Input text to highlight.
   @param style Desired highlight style.
   @return Input text with highlighted style.
   */
  String highlight(String text, SStyle style);
}
