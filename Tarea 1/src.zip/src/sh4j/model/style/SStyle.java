
package sh4j.model.style;

/**
 SStyle Interface.
 First sentence should be present.
 Meaning that there should be more than one line.

 @author Gabriel De La Parra
 @version 1.0 */
public interface SStyle {
  /**
   Style's to string Method.
   First sentence should be present.
   Meaning that there should be more than one line.

   @return Style identifier.
   */
  String toString();

  /**
   Checks if text requires highlighting.
   First sentence should be present.
   Meaning that there should be more than one line.

   @param styleName style name.
   @return compares with current style name.
   */
  boolean isStyle(String styleName);
}
