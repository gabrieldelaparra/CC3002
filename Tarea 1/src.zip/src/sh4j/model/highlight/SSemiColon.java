package sh4j.model.highlight;

import sh4j.model.style.SStyle;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 SSemiColon highligther Style Class.
 First sentence should be present.
 Meaning that there should be more than one line.

 @author Gabriel De La Parra
 @version 1.0 */
public class SSemiColon implements SHighlighter {
  /**
   Highlightable Keywords collection.
   First sentence should be present.
   Meaning that there should be more than one line.
   */
  private final Set<String> javaKeywords =
      new HashSet<>(Collections.singletonList(";"));

  /**
   First sentence should be present.
   Meaning that there should be more than one line.

   @param text Input text that might be highlighted.
   @return Returns true if the text needs to be highlighted.
   */
  @Override
  public boolean needsHighLight(String text) {
    return javaKeywords.contains(text);
  }

  /**
   First sentence should be present.
   Meaning that there should be more than one line.

   @param text Input text to highlight.
   @param style Desired highlight style.
   @return Input text with highlighted style.
   */
  @Override
  public String highlight(String text, SStyle style) {
    String result;
    if (style.isStyle("eclipse")) {
      result = text;
    } else if (style.isStyle("dark")) {
      result = "<span style='color:#b060b0; '>" + text + "</span>";
    } else {
      result = "<span style='color:#806030; '>" + text + "</span>";
    }
    return result;
  }
}
