package test;

import org.junit.Before;
import org.junit.Test;
import sh4j.model.highlight.SPseudoVariable;
import sh4j.model.highlight.SSemiColon;
import sh4j.model.style.SBredStyle;
import sh4j.model.style.SDarkStyle;
import sh4j.model.style.SEclipseStyle;
import sh4j.parser.SParser;
import sh4j.parser.model.SBlock;

import static org.junit.Assert.assertEquals;

/**
 First sentence should be present.
 Meaning that there should be more than one line.
 */
public class SStyleNameTest {

  /**
   First sentence should be present.
   Meaning that there should be more than one line.
   */
  @Test
  public void testDarkStyleName() {
    assertEquals(new SDarkStyle().toString(), "dark");
  }

  /**
   First sentence should be present.
   Meaning that there should be more than one line.
   */
  @Test
  public void testBredStyleName() {
    assertEquals(new SBredStyle().toString(), "bred");
  }

  /**
   First sentence should be present.
   Meaning that there should be more than one line.
   */
  @Test
  public void testEclipseStyleName() {
    assertEquals(new SEclipseStyle().toString(), "eclipse");
  }
}
