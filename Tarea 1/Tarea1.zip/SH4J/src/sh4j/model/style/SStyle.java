package sh4j.model.style;

public interface SStyle {
	
	public String toString();
	
}
