package sh4j.model.style;

public class SEclipseStyle implements SStyle{
	public String toString() {
		return "eclipse";
	}
}
