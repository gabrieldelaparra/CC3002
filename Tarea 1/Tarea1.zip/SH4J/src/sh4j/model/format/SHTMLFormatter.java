package sh4j.model.format;

import sh4j.model.highlight.*;
import sh4j.model.style.*;
import sh4j.parser.model.*;

public class SHTMLFormatter implements SFormatter{
	private StringBuffer buffer;
	private int level;
	private SStyle style;
	private SHighlighter[] highlighters;
	
	public SHTMLFormatter(SStyle style, SHighlighter... hs){
		this.style = style;
		highlighters = hs;
		buffer=new StringBuffer();
	}
	
	private SHighlighter lookup(String text){
		for(SHighlighter h: highlighters){
			if(h.needsHighLight(text)){
				return h;
			}
		}
		return new SDummy();
	}
	
	@Override
	public void styledWord(String word) {
		buffer.append(lookup(word).highlight(word, style));
	}

	@Override
	public void styledChar(char c) {
		buffer.append(lookup(c+"").highlight(c+"", style));
	}

	@Override
	public void styledSpace() {
		buffer.append(' ');
	}

	@Override
	public void styledCR() {
		buffer.append('\n');
		indent();
	}

	@Override
	public void styledBlock(SBlock b) {
		level++;
		for(SText text: b.texts()){
			text.export(this);
		}
		level--;
	}
	
	public void indent(){
		for(int i=0;i<level;i++) buffer.append("  ");
	}
	
	@Override
	public String formattedText() {
		return "<pre style='color:#000000;background:#ffffff;'>"+buffer.toString()+"</pre>";
	}
}
