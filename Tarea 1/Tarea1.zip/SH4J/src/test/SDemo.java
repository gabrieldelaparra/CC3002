package test;

import sh4j.model.highlight.SKeyWord;
import sh4j.model.style.SEclipseStyle;
import sh4j.parser.SParser;

public class SDemo {
	public static void main(String[] args) {
		String html=SParser.parse("public class Demo{}").toHTML(new SEclipseStyle(),new SKeyWord());
		System.out.println(html);
	}
}
