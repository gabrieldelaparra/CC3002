package sh4j.model.format;

import sh4j.parser.model.SBlock;
import sh4j.parser.model.SText;

public class SPlainFormatter implements SFormatter{

    private StringBuffer buffer;
    private int level;

    public SPlainFormatter(){
        buffer=new StringBuffer();
    }
    @Override
    public void styledWord(String word) {
        buffer.append(word);
    }

    @Override
    public void styledChar(char c) {
        buffer.append(c);
    }

    @Override
    public void styledSpace() {
        buffer.append(' ');
    }

    @Override
    public void styledCR() {
        buffer.append('\n');
        indent();
    }

    @Override
    public void styledBlock(SBlock b) {
        level++;
        for(SText text: b.texts()){
            text.export(this);
        }
        level--;
    }

    public void indent(){
        for(int i=0;i<level;i++) buffer.append("  ");
    }

    @Override
    public String formattedText() {
        return buffer.toString();
    }

}
