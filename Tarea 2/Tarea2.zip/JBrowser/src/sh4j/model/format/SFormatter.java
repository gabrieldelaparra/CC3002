package sh4j.model.format;

import sh4j.parser.model.SBlock;

public interface SFormatter {
    public void styledWord(String word);
    public void styledChar(char c);
    public void styledSpace();
    public void styledCR();
    public void styledBlock(SBlock b);
    public String formattedText();
}
