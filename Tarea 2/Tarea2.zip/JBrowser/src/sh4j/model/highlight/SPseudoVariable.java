package sh4j.model.highlight;

import sh4j.model.style.SStyle;

public class SPseudoVariable implements SHighlighter{

	@Override
	public boolean needsHighLight(String text) {
		return text.equals("super")|| text.equals("this");
	}

	@Override
	public String highlight(String text, SStyle style) {
		return style.formatPseudoVariable(text);
	}

	
}
