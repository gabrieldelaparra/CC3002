package sh4j.model.browser;

public interface SObject {

}
