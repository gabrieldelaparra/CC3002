package sh4j.model.browser;

import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import sh4j.parser.SClassParser;

/**
 * Create object of classes SMethod, SClass and SPackage
 * @author juampi
 *
 */
public class SFactory {
    
	/**
	 * Create a SProject based in a String path
	 * @param path
	 * @return
	 * @throws IOException
	 */
    public SProject create(String path) throws IOException{
        File directory=new File(path);
        List<File> folders=new ArrayList<File>();
        fillFolders(folders,directory);
        SProject project=new SProject();
        for(File file: folders){
            project.addPackage(createPackage(file, directory.getCanonicalPath()));
        }
        return project;
    }
    
    /**
     * Create an SPackage using a String path
     * @param root
     * @param path
     * @return
     * @throws IOException
     */
    public SPackage createPackage(File root,String path) throws IOException{
        SPackage pack=new SPackage(root.getCanonicalPath().replace(path,""));
        for(File file: root.listFiles()){
            if(file.isFile() && file.getName().endsWith(".java")){
                List<SClass> classes=createClass(file);
                for(SClass cls: classes){
                    pack.addClass(cls);
                }
            }
        }
        return pack;
    }
    
    /**
     * Create the classes inside the file passed as argument.
     * @param root
     * @return
     * @throws IOException
     */
    public List<SClass> createClass(File root) throws IOException{
        Path path=Paths.get(root.getPath());
        Charset charset = Charset.forName("ISO-8859-1");
        List<String> lines=Files.readAllLines(path,charset);
        StringBuilder code=new StringBuilder();
        for(String line:lines){
            code.append(line);
        }
        return SClassParser.parse(code.toString());
    }
    
    private void fillFolders(List<File> folders, File root){
        if(root.isDirectory()){
            folders.add(root);
            for(File file: root.listFiles()){
                fillFolders(folders,file);
            }
        }
    }
}
