package sh4j.model.browser;

import java.util.ArrayList;
import java.util.List;

public class SProject implements SObject{
    private List<SPackage> packages;
    
    public SProject(){
        packages=new ArrayList<SPackage>();
    }
    
    public void addPackage(SPackage pack){
        packages.add(pack);
    }
    public List<SPackage> packages(){
        return packages;
    }
    
    public SPackage get(String pkgName){
        for(SPackage pkg: packages){
            if(pkg.toString().equals(pkgName)){
                return pkg;
            }
        }
        return null;
    }
   
}
