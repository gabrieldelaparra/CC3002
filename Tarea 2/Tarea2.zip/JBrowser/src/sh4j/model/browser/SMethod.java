package sh4j.model.browser;

import org.eclipse.jdt.core.dom.MethodDeclaration;
import org.eclipse.jdt.core.dom.Modifier;

import sh4j.parser.model.SBlock;

public class SMethod implements SObject{
    private MethodDeclaration declaration;
    private SBlock body;

    public SMethod(MethodDeclaration node,SBlock body) {
        declaration=node;
        this.body=body;
    }

    public String modifier(){       
        for(Object obj : declaration.modifiers()){
            if(obj instanceof Modifier){
                Modifier modifier= (Modifier) obj;
                return modifier.getKeyword().toString();
            }
        }
        return "default";
    }

    public String name(){
        return declaration.getName().getIdentifier();
    }

    public SBlock body() {
        return body;
    }
    
    public String toString(){
    		return name();
    }

}
