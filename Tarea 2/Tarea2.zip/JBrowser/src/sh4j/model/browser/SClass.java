package sh4j.model.browser;

import java.util.List;
import org.eclipse.jdt.core.dom.TypeDeclaration;

public class SClass implements SObject{
    private TypeDeclaration declaration;
    private List<SMethod> methods;
    public SClass(TypeDeclaration td, List<SMethod> ms){
        declaration=td;
        methods=ms;
    }
    public List<SMethod> methods(){
        return methods;
    }
    public String className(){
        return declaration.getName().getIdentifier();
    }
    public boolean isInterface(){
        return declaration.isInterface();
    }

    public String superClass(){
        if(declaration.getSuperclassType()==null) return "Object";
        return declaration.getSuperclassType().toString();
    }
    public String toString(){
    		return className();
    }
}