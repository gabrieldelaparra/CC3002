package sh4j.model.browser;

import java.util.ArrayList;
import java.util.List;

public class SPackage implements SObject{

    private String name;
    private List<SClass> classes;
    public SPackage(String name) {
        classes =new ArrayList<SClass>();
        this.name=name;
    }
    
    public void addClass(SClass cls){
        classes.add(cls);
    }

    public List<SClass> classes(){
        return classes;
    }
    public String toString(){
        return name;
    }
}
